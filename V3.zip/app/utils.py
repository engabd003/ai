from pyrogram import filters, types
import json
from app.values import DATA_DANTIC, DATA_PATH
from datetime import datetime, timedelta


def getData():
    with open(DATA_PATH, 'r', encoding='utf-8') as ioFile:
        return json.load(ioFile)

def updateData(newData: dict):
    with open(DATA_PATH, 'w', encoding='utf-8') as ioFile:
        json.dump(newData, ioFile, indent=3)


def IS_SPLIT(data):
    def func(flt, _, Q: types.CallbackQuery):
        return flt.data == Q.data.split("|")[0]
    return filters.create(func=func, data=data)


def check_subscription(user_id: int):
    """Check if user has active subscription"""
    botData = getData()
    user_id_str = str(user_id)

    if user_id_str not in botData.get('subscriptions', {}):
        return False, 'no_subscription'

    sub_data = botData['subscriptions'][user_id_str]
    expiry_date = datetime.fromisoformat(sub_data['expiry_date'])

    if datetime.now() > expiry_date:
        return False, 'expired'

    return True, sub_data['type']


def add_subscription(user_id: int, days: int, sub_type: str = 'VIP'):
    """Add or extend subscription for user"""
    botData = getData()
    user_id_str = str(user_id)

    if 'subscriptions' not in botData:
        botData['subscriptions'] = {}

    if user_id_str in botData['subscriptions']:
        current_expiry = datetime.fromisoformat(botData['subscriptions'][user_id_str]['expiry_date'])
        if current_expiry > datetime.now():
            new_expiry = current_expiry + timedelta(days=days)
        else:
            new_expiry = datetime.now() + timedelta(days=days)
    else:
        new_expiry = datetime.now() + timedelta(days=days)

    botData['subscriptions'][user_id_str] = {
        'type': sub_type,
        'expiry_date': new_expiry.isoformat(),
        'start_date': datetime.now().isoformat()
    }

    updateData(botData)
    return new_expiry


def get_subscription_info(user_id: int):
    """Get subscription info for user"""
    botData = getData()
    user_id_str = str(user_id)

    if user_id_str not in botData.get('subscriptions', {}):
        return None

    sub_data = botData['subscriptions'][user_id_str]
    expiry_date = datetime.fromisoformat(sub_data['expiry_date'])
    days_left = (expiry_date - datetime.now()).days

    return {
        'type': sub_data['type'],
        'expiry_date': expiry_date,
        'days_left': max(0, days_left)
    }